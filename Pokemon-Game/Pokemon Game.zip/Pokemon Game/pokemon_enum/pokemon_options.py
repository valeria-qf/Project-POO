from enum import Enum

class PokemonOptions(Enum):
    atacar = 1
    defender = 2
    ataque_especial = 3

    def print_your_option(option) -> str:
            return ' escolheu {}'.format(option.name)

    def print_values():
            return '1 - Atacar \n2 - Defender \n3 - Ataque especial\n'
            