from pokemon.bubasaur.bubasaur import Bubasaur
from pokemon.squirtle.squirtle import Squirtle
from pokemon.bubasaur.venusaur import Venusaur
from pokemon.charmander.charmander import Charmander
from pokemon.bubasaur.ivysaur import Ivysaur
from arena.arena import Arena


b1 = Bubasaur(special_attack= 100)
b2 = Charmander()
arena = Arena(A = b1, B = b2)

print(b1)
#arena.batalhar()
