from implementation.pokemon import Pokemon
from pokemon_enum.pokemon_options import PokemonOptions
class Arena:


    def __init__(self, A: Pokemon, B: Pokemon) -> None:
        self.A = A
        self.B = B

    def batalhar(self):
        while ((self.A.get_hp() > 0) and (self.B.get_hp() > 0)):

            print(self.A.list_options())

            acaoJogador1 = input('JOGADOR 1: Escolha uma opção acima:\n')
            acaoJogador2 = input('JOGADOR 2: Escolha uma opção acima:\n')

            # BLOCO 1
            if acaoJogador1 == '1' and acaoJogador2 == '1':
                self.action(PokemonOptions.atacar, PokemonOptions.atacar)

            elif acaoJogador1 == '1' and acaoJogador2 == '2':
                self.action(PokemonOptions.atacar, PokemonOptions.defender)

            elif acaoJogador1 == '1' and acaoJogador2 == '3':
                self.action(PokemonOptions.atacar, PokemonOptions.ataque_especial)

            # BLOCO 2
            elif acaoJogador1 == '2' and acaoJogador2 == '1':
                self.action(PokemonOptions.defender, PokemonOptions.atacar)

            elif acaoJogador1 == '2' and acaoJogador2 == '2':
                self.action(PokemonOptions.defender, PokemonOptions.defender)
        
            elif acaoJogador1 == '2' and acaoJogador2 == '3':
                self.action(PokemonOptions.defender, PokemonOptions.ataque_especial)

            # BLOCO 3
            elif acaoJogador1 == '3' and acaoJogador2 == '1':
                self.action(PokemonOptions.ataque_especial, PokemonOptions.atacar)

            elif acaoJogador1 == '3' and acaoJogador2 == '2':
                self.action(PokemonOptions.ataque_especial, PokemonOptions.defender)

            elif acaoJogador1 == '3' and acaoJogador2 == '3':
                self.action(PokemonOptions.ataque_especial, PokemonOptions.ataque_especial)

            else:
                print('Opção inválida, tente novamente\n')

        # CHECA QUEM VENCEU E INCREMENTA NUMERO DE VITORIAS E DERROTAS
        if self.A.get_hp() == 0:
            self.A.set_numero_derrotas()

            print('--------------------\n{} VENCEU!\n--------------------'.format(self.B.get_pokemon()))
            self.B.set_numero_vitorias()

            print('\n*** EVOLUÇÃO! *** \n{}'.format(self.B))


        elif self.B.get_hp() == 0:

            self.B.set_numero_derrotas()

            print('--------------------\n{} VENCEU!\n--------------------'.format(self.A.get_pokemon()))
            self.A.set_numero_vitorias()

            
            print('\n*** EVOLUÇÃO! *** \n{}'.format(self.A))
            
    # método action utilizando Enum
    def action(self, option1: PokemonOptions, option2: PokemonOptions):

        '''print('\n-------------------------------\nJOGADOR 1{} \nJOGADOR 2{}\n-------------------------------'.format(option1.print_your_option(),option2.print_your_option()))'''

        # BLOCO 1.1
        if option1 == PokemonOptions.atacar and option2 == PokemonOptions.atacar:

            self.A.atacar(self.B)
            self.B.atacar(self.A)
        
            self.print_hp()

        # BLOCO 1.2
        elif option1 == PokemonOptions.atacar and option2 == PokemonOptions.defender:
            
            self.B.defender(self.A)

            self.print_hp()

        # BLOCO 1.3
        elif option1 == PokemonOptions.atacar and option2 == PokemonOptions.ataque_especial:

            self.A.atacar(self.B)
            self.B.ataque_especial(self.A)

            self.print_hp()

        # BLOCO 2.1
        elif option1 == PokemonOptions.defender and option2 == PokemonOptions.atacar:

            defesaA = self.A.get_defense()
            ataqueB = self.B.get_attack()

            self.A.defender(self.B)
            
            self.print_hp()

        # BLOCO 2.2
        elif option1 == PokemonOptions.defender and option2 == PokemonOptions.defender:

            self.print_hp()

        # BLOCO 2.3
        elif option1 == PokemonOptions.defender and option2 == PokemonOptions.ataque_especial:

            self.B.ataque_especial(self.A)
            self.A.defender(self.B, is_special_attack = True)

            self.print_hp()

        # BLOCO 3.1
        elif option1 == PokemonOptions.ataque_especial and option2 == PokemonOptions.atacar:
            
            self.A.ataque_especial(self.B)
            self.B.atacar(self.A)
        
            self.print_hp()

        # BLOCO 3.2
        elif option1 == PokemonOptions.ataque_especial and option2 == PokemonOptions.defender:

            self.A.ataque_especial(self.B)
            self.B.defender(self.A, is_special_attack = True)

            self.print_hp()

        # BLOCO 3.3
        elif option1 == PokemonOptions.ataque_especial and option2 == PokemonOptions.ataque_especial:
            self.A.ataque_especial(self.B)
            self.B.ataque_especial(self.A)

            self.print_hp()

    def print_hp(self):

        print('\n------------------------\nHP DE {} = {} \nHP DE {} = {}\n------------------------\n'.format(self.A.get_pokemon(), self.A.get_hp(), self.B.get_pokemon(), self.B.get_hp()))