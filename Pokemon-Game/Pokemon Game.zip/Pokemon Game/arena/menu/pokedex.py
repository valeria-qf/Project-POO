from pokemon_list.pokemon_list import PokemonList
from arena.arena import Arena
from implementation.pokemon import Pokemon
from pokemon.bubasaur.bubasaur import Bubasaur
from pokemon.bubasaur.ivysaur import Ivysaur
from pokemon.bubasaur.venusaur import Venusaur
from pokemon.charmander.charmander import Charmander
from pokemon.charmander.charmeleon import Charmeleon
from pokemon.charmander.charizard import Charizard
from pokemon.squirtle.squirtle import Squirtle
from pokemon.squirtle.wartortle import Wartortle
from pokemon.squirtle.blastoise import Blastoise
import sys

class Pokedex:

    def __init__(self, pokemon_list: PokemonList, arena: Arena) -> None:
        self.__pokemon_list = pokemon_list
        self.__arena = arena

    def select_pokemon_level(self):
        pokemon_level = int(input('Selecione o nível dos Pokémon que irão batalhar:\n\n1 - Nível 1 \n2 - Nível 2 \n3 - Nível 3\n'))

        print('Escolha um Pokémon abaixo:')
    
        if pokemon_level == 1:
            self.__pokemon_list.list_pokemon_level1()
            fist_pokemon = int(input())
            second_pokemon = int(input())
            pokemon_one = self.create_pokemon(pokemon_level, fist_pokemon)
            pokemon_two = self.create_pokemon(pokemon_level, second_pokemon)

        elif pokemon_level == 2:
            self.__pokemon_list.list_pokemon_level2()
            fist_pokemon = int(input())
            second_pokemon = int(input())
            pokemon_one = self.create_pokemon(pokemon_level, fist_pokemon)
            pokemon_two = self.create_pokemon(pokemon_level, second_pokemon)

        elif pokemon_level == 3:

            self.__pokemon_list.list_pokemon_level3()
            fist_pokemon = int(input())
            second_pokemon = int(input())
            pokemon_one = self.create_pokemon(pokemon_level, fist_pokemon)
            pokemon_two = self.create_pokemon(pokemon_level, second_pokemon)

        else:
            print('\nOpção inválida, tente novamente!')

    def create_pokemon(self, level: int, pokemon_option: int) -> Pokemon:
        
        if (level < 0 or level > 3) or (pokemon_option < 0 or pokemon_option > 3):
            return Exception('Opção inválida, tente novamente!')

        elif level == 1:
            if pokemon_option == 1:
                return Bubasaur()

            elif pokemon_option == 2:
                return Charmander()

            elif pokemon_option == 3:
                return Squirtle()

        elif level == 2:
            if pokemon_option == 1:
                return Ivysaur()
            
            elif pokemon_option == 2:
                return Charmeleon()

            elif pokemon_option == 3:
                return Wartortle()

        elif level == 3:
            if pokemon_option ==1:
                return Venusaur()

            elif pokemon_option == 2:
                return Charizard()

            elif pokemon_option == 3:
                return Blastoise()