from enum import Enum

class PokemonLevelTwo(Enum):
    ivysaur = 1
    charmeleon = 2
    wartortle = 3

    def print_values():
            print('\n1 - Ivysaur \n2 - Charmeleon \n3 - Wartortle')