from enum import Enum

class PokemonLevelThree(Enum):
    venusaur = 1
    charizard = 2
    blastoise = 3

    def print_values():
            print('\n1 - Venusaur \n2 - Charizard \n3 - Blastoise')
