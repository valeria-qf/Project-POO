from enum import Enum

class PokemonLevelOne(Enum):
    bubasaur = 1
    charmander = 2
    squirtle = 3

    def print_values():
            print('\n1 - Bubasaur \n2 - Charmander \n3 - Squirtle')
